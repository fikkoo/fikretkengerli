
let q = document.querySelector('.question');
let a = document.querySelector('.ans1');
let b = document.querySelector('.ans2');
let c = document.querySelector('.ans3');
let d = document.querySelector('.ans4');
let rewards = document.querySelectorAll("ul li");
let questions = [
    ["What sort of animal is Walt Disney's Dumbo?",'Donkey','Deer','Elephant','Rabbit','Elephant'],
    ['What was the name of the Spanish waiter in the TV sitcom "Fawlty Towers"?','Pedro','Manuel','Alfonso','Javier','Manuel'],
    ['Which battles took place between the Royal Houses of York and Lancaster?','Hundred Years War','Thirty Years War','War of the Roses','English Civil War','War of the Roses'],
    ['Which former Beatle narrated the TV adventures of Thomas the Tank Engine?','Ringo Starr','John Lennon','Paul McCartney','George Harrison','Ringo Starr'],
    ['Queen Anne was the daughter of which English Monarch?','James II','Henry VIII','Victoria','William I', 'James II'],
    ['Who composed "Rhapsody in Blue"?','George Gershwin','Irving Berlin','Aaron Copland','Cole Porter','George Gershwin'],
    ['What is the Celsius equivalent of 77 degrees Fahrenheit?','15','20','25','30', '25'],
    ['Suffolk Punch and Hackney are types of what?','Carriage','Wrestling style','Cocktail','Horse','Horse'],
    ['Which Shakespeare play features the line "Neither a borrower nor a lender be"?','Hamlet','Macbeth','Othello','The Merchant of Venice', 'Hamlet'],
    ["Which is the largest city in the USA's largest state?",'Dallas','Los Angeles','New York','Anchorage','Anchorage'],
    ['The word "aristocracy" literally means power in the hands of whom?','The few','The best','The barons','The rich', 'The best'],
    ['Where would a "peruke" be worn?','Around the neck','On the head','Around the waist','On the wrist','On the head'],
    ['In which palace was Queen Elizabeth I born?','Greenwich','Richmond','Hampton Court','Kensington', 'Greenwich']
]

let numb = 0;
money(0)

let questionWritter = (numb)=> {
// let questionWritter = function (numb) {
q.innerHTML = questions[numb][0]
a.innerHTML = questions[numb][1]
b.innerHTML = questions[numb][2]
c.innerHTML = questions[numb][3]
d.innerHTML = questions[numb][4]

}

questionWritter(numb);

let testo = (a)=>{


if (a == questions[numb][5]){
numb = numb+1;


//maxlength ile edeceyik
questionWritter(numb);
money(numb)

}

else {
  alert("False!")
}
}


function entergame() {
  var main = document.querySelector(".main");
  var game = document.querySelector(".game");
  var music = document.querySelector("#song");
  main.style.display = "none"
  game.style.display = "block"
  music.currentTime = 0;
  music.play()
  music.loop=true


}


function returnb() {
  var main = document.querySelector(".main");
  var game = document.querySelector(".game");
  var music = document.querySelector("#song");
  main.style.display = "block"
  game.style.display = "none"
  music.pause()
}

function money(par){

  let x = 12-par;
  for (let i = 0; i < rewards.length; i++){
    rewards[i].style.backgroundColor = "rgba(173,216,230,0.5)";
    rewards[i].style.color = "black";
  }
    rewards[x].style.backgroundColor = "blue";
    rewards[x].style.color = "white";


}



function closegame(){
  window.close()
}
